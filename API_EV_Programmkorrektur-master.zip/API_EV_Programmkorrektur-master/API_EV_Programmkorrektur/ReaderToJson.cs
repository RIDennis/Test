﻿using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data;
using System.Text.Json.Serialization;

namespace API_EV_Programmkorrektur
{
    public class ReaderToJsonClass
    {
        public string getJsonFromReader(OracleDataReader reader)
        {
            var startJson = DateTime.Now;
            /*
            var dataTable = new DataTable();
            dataTable.Load(reader); 
            string jsonString = string.Empty;
            jsonString = JsonConvert.SerializeObject(dataTable);
            */
            var jsonString = "";
            var table = reader.GetSchemaTable();
            List<String> columns = new List<String>();
            List<object> datatypes = new List<object>();
            if (table!=null) { 
            foreach (DataRow row in table.Rows)
            {
                columns.Add(row.Field<String>("ColumnName"));
                datatypes.Add(row["DataType"]);
            }
            jsonString += "{\n\"result\": [\n";
            while (reader.Read())
            {
                jsonString += "\t{\n";
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    OracleString oraclestring1 = reader.GetOracleString(i);
                    dynamic myObject = datatypes[i];
                    if (myObject.Name == "String")
                    {
                        if (oraclestring1.ToString() == "null")
                        {
                            jsonString += "\t\"" + columns[i] + "\": " + oraclestring1.ToString() + ",\n";
                        }
                        else
                        {
                            jsonString += "\t\"" + columns[i] + "\": \"" + oraclestring1.ToString() + "\",\n";
                        }
                    }
                    else if(myObject.Name == "DateTime")
                    {
                        var date = oraclestring1.ToString();
                        if(date != "null") 
                        {
                            var array = date.Split(date.Substring(2,1));
                            var newDate =  "20" + array[2] + "-" + array[1] + "-" + array[0];
                            jsonString += "\t\"" + columns[i] + "\": \"" + newDate + "\",\n";
                        }else
                        {
                            jsonString += "\t\"" + columns[i] + "\": null,\n";
                        }
                    }
                    else if (myObject.Name == "Decimal" || myObject.Name == "Double")
                    {
                        var decim = oraclestring1.ToString();
                        var newDecim = decim.Replace(",", ".");
                        jsonString += "\t\"" + columns[i] + "\": " + newDecim + ",\n";
                    }
                    else 
                    {
                        jsonString += "\t\"" + columns[i] + "\": " + oraclestring1.ToString() + ",\n";
                    }
                }
                jsonString = jsonString.Substring(0, jsonString.Length - 2);
                jsonString += "\n\t},\n";
                }
                jsonString = jsonString.Substring(0, jsonString.Length - 2);
                jsonString += "\n]\n}";
        //    Console.WriteLine(jsonString);
            reader.Close();            

            var endJson = DateTime.Now;
            Console.WriteLine("TimetoExecuteJson: " + (endJson - startJson));
                if(jsonString.Length == 16)
                {
                    jsonString =  "{\"result\": \"No Data Found\"}";
                }
            return jsonString;
            }
            else
            {
                return "{\"result\": \"No Data Found\"}";
            }
    }
    }
}
