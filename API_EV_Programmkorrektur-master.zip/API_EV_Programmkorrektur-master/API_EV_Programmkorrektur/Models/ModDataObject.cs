﻿namespace API_EV_Programmkorrektur.Models
{
    public class ModDataObject
    {
        public int AVPR_KORR_ANFO_POS_ID { get; set; }
        public int? AVPR_KORR_ANFO_ROHDATEN_ID { get; set; }
        public String? Modell { get; set; }
    }
}
