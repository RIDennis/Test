﻿namespace API_EV_Programmkorrektur.Models
{
    public class EmailDataObject
    {
        public int? ANZ_APOS_STICHTAG { get; set; }
        public int? ANZ_ARTIKEL { get; set; }
        public int? ANZ_ARTIKEL_EV { get; set; }
        public int? ANZ_MODELLE { get; set; }
        public int? ANZ_MODELLE_EV { get; set; }
        public int? MENGE { get; set; }
        public int? MENGE_EV { get; set; }
        public int? AVPR_KORR_ANFO_ID { get; set; }
        public int? AVPR_KORR_ANFO_POS_ID { get; set; }
        public string? CALCPATH { get; set; }
        public string? NAME { get; set; }
        public string? NUMMER { get; set; }
        public int? EVKDG_ID { get; set; }
        public string? KUNDEN_ID { get; set; }
        public string? PATH { get; set; }
        public string? STATUS { get; set; }
        public string? VERARBEITET_VON { get; set; }
        public DateTime? VERARBEITET_AM { get; set; }
        public float? ANTEIL_EV { get; set; }
        public decimal? ABWEICHUNG { get; set; }
        public float? WERT_EV { get; set; }
        public float? ANTEIL_EV_NEU { get; set; }
        public float? WERT { get; set; }
        public bool ShouldbeProcessed { get; set; }
        public string? TYP { get; set; }
    }
}

