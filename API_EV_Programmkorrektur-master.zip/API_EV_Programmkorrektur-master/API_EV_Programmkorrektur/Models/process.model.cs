﻿namespace API_EV_Programmkorrektur.Models
{
    public class process
    {
        public int? VERTRIEBSORGANISATIONS_ID { get; set; }
        public int? SAISON_ID { get; set; }
        public DateTime? STICHTAG { get; set; }
        public string? STATUS { get; set; }
        public string? BEMERKUNG { get; set; }
        public string? ERSTELLT_VON { get; set; }

    }

}
