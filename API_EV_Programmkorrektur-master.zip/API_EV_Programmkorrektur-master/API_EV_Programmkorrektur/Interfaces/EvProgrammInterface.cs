﻿
using API_EV_Programmkorrektur.Models;

namespace API_EV_Programmkorrektur.Interfaces
{
    public interface IEvProgrammService
    {
        String createProcess(process s);
        String GetSaisonList();
        String GetSprachList();
        String GetUebersicht();
        String GetVOList();
        String GET_AVPR_KORR_ANFO_EVART_LST(Int32 AVPR_KORR_ANFO_ID);
        String GET_AVPR_KORR_ANFO_POS_LST(Int32 AVPR_KORR_ANFO_ID);
        String GET_AVPR_KORR_ANFO_POS_LST(Int32 AVPR_KORR_ANFO_ID, String TYP);
        String GET_AVPR_KORR_ANFO_ROH_LST(Int32 AVPR_KORR_ANFO_ID, Int32 AVPR_KORR_ANFO_POS_ID, String TYP);
        String MOD_AVPR_KORR_ANFO_ROHDATEN(String TYP, ModDataObject[] eingabeRohdaten);
        String RECALC_AVPR_KORR_ANFO_POS(Int32 AVPR_KORR_ANFO_POS_ID);
        String RECALC_AVPR_KORR_ANFO_POSIDS(Int32[] AVPR_KORR_ANFO_POS_IDs);
        String GET_AVPR_KORR_ANFO_PROT_LST(Int32 AVPR_KORR_ANFO_ID);
    }
}
