﻿using API_EV_Programmkorrektur.Interfaces;
using API_EV_Programmkorrektur.Models;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Reflection;

namespace API_EV_Programmkorrektur.Services
{
    public class EvProgrammService : IEvProgrammService
    {

        private readonly string _connectionStringProd;
        private readonly string _connectionString;

        public EvProgrammService(IConfiguration _configuration)
        {
            _connectionStringProd = _configuration.GetConnectionString("ProdConnectionString");
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public string createProcess(process s)
        {
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.ADD_AVPR_KORR_ANFO";

                    OracleParameter inVERTRIEBSORGANISATIONS_ID = new OracleParameter("inVERTRIEBSORGANISATIONS_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inVERTRIEBSORGANISATIONS_ID.Value = s.VERTRIEBSORGANISATIONS_ID;
                    cmd.Parameters.Add(inVERTRIEBSORGANISATIONS_ID);

                    OracleParameter inSAISON_ID = new OracleParameter("inSAISON_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inSAISON_ID.Value = s.SAISON_ID;
                    cmd.Parameters.Add(inSAISON_ID);

                    OracleParameter inSTICHTAG = new OracleParameter("inSTICHTAG", OracleDbType.Date, System.Data.ParameterDirection.Input);
                    inSTICHTAG.Value = s.STICHTAG;
                    cmd.Parameters.Add(inSTICHTAG);

                    OracleParameter inSTATUS = new OracleParameter("inSTATUS", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inSTATUS.Value = s.STATUS;
                    cmd.Parameters.Add(inSTATUS);

                    OracleParameter inBEMERKUNG = new OracleParameter("inBEMERKUNG", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inBEMERKUNG.Value = s.BEMERKUNG;
                    cmd.Parameters.Add(inBEMERKUNG);

                    OracleParameter inERSTELLT_VON = new OracleParameter("inERSTELLT_VON", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inERSTELLT_VON.Value = s.ERSTELLT_VON;
                    cmd.Parameters.Add(inERSTELLT_VON);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    con.Dispose();
                    con.Close();
                    return result.ToString();
                }
            }
        }

        public string GetSaisonList()
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_SAISON_LST";

                    OracleParameter outSAISONLST = new OracleParameter("outSAISONLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outSAISONLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }
        public string GetSprachList()
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionString))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "RI_WEBACCESS.RIWAPKG_BENUTZER_ROLLEN_MGMT.GET_SPRACH_LST";

                    OracleParameter inWEBBENUTZER_NAME = new OracleParameter("inWEBBENUTZER_NAME", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inWEBBENUTZER_NAME.Value = "n.behrendt@is-int-sourcing.ch";
                    cmd.Parameters.Add(inWEBBENUTZER_NAME);

                    OracleParameter inSELECTED_SPRACHE = new OracleParameter("inSELECTED_SPRACHE", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inSELECTED_SPRACHE.Value = 7;
                    cmd.Parameters.Add(inSELECTED_SPRACHE);

                    OracleParameter outSprachLst = new OracleParameter("outSprachLst", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outSprachLst);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string GetUebersicht()
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_LST";

                    OracleParameter outAVPRKORRANFOLST = new OracleParameter("outAVPRKORRANFOLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    
                    return jsonString;
                }
            }
        }

        public string GET_AVPR_KORR_ANFO_POS_LST(Int32 AVPR_KORR_ANFO_ID)
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_POS_LST";

                    OracleParameter inAVPR_KORR_ANFO_ID = new OracleParameter("inAVPR_KORR_ANFO_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_ID.Value = AVPR_KORR_ANFO_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_ID);

                    OracleParameter outAVPRKORRANFOPOSLST = new OracleParameter("outAVPRKORRANFOPOSLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOPOSLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    var startsql = DateTime.Now;
                    Console.WriteLine(startsql);
                    cmd.ExecuteNonQuery();
                    var endsql = DateTime.Now;
                    Console.WriteLine(endsql);

                    Console.WriteLine("TimetoExecute: " + (endsql-startsql));
                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string GET_AVPR_KORR_ANFO_POS_LST(Int32 AVPR_KORR_ANFO_ID, String TYP)
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_POS_LST";

                    OracleParameter inAVPR_KORR_ANFO_ID = new OracleParameter("inAVPR_KORR_ANFO_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_ID.Value = AVPR_KORR_ANFO_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_ID);

                    OracleParameter inTYP = new OracleParameter("inTYP", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inTYP.Value = TYP;
                    cmd.Parameters.Add(inTYP);

                    OracleParameter outAVPRKORRANFOPOSLST = new OracleParameter("outAVPRKORRANFOPOSLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOPOSLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    var startsql = DateTime.Now;
                    Console.WriteLine(startsql);
                    cmd.ExecuteNonQuery();
                    var endsql = DateTime.Now;
                    Console.WriteLine(endsql);

                    Console.WriteLine("TimetoExecute: " + (endsql - startsql));
                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string GetVOList()
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_VO_LST";

                    OracleParameter outVOLST = new OracleParameter("outVOLST ", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outVOLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string GET_AVPR_KORR_ANFO_ROH_LST(Int32 AVPR_KORR_ANFO_ID, Int32 AVPR_KORR_ANFO_POS_ID, String TYP)
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_ROH_LST";

                    OracleParameter inAVPR_KORR_ANFO_ID = new OracleParameter("inAVPR_KORR_ANFO_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_ID.Value = AVPR_KORR_ANFO_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_ID);

                    OracleParameter inAVPR_KORR_ANFO_POS_ID = new OracleParameter("inAVPR_KORR_ANFO_POS_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_POS_ID.Value = AVPR_KORR_ANFO_POS_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_POS_ID);

                    OracleParameter inTYP = new OracleParameter("inTYP", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                    inTYP.Value = TYP;
                    cmd.Parameters.Add(inTYP);

                    OracleParameter outAVPRKORRANFOROHLST = new OracleParameter("outAVPRKORRANFOROHLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOROHLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);


                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string MOD_AVPR_KORR_ANFO_ROHDATEN(string TYP, ModDataObject[] eingabeRohdaten)
        {
            var gesamtResult = "1";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                con.Open(); 
                for (int i = 0; i < eingabeRohdaten.Length; i++)
                {
                    using (OracleCommand cmd = new OracleCommand("", con))
                    {
                        cmd.BindByName = true;
                        cmd.CommandType = System.Data.CommandType.StoredProcedure;
                        cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.MOD_AVPR_KORR_ANFO_ROHDATEN";
                    
                        OracleParameter inAVPR_KORR_ANFO_POS_ID = new OracleParameter("inAVPR_KORR_ANFO_POS_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                        inAVPR_KORR_ANFO_POS_ID.Value = eingabeRohdaten[i].AVPR_KORR_ANFO_POS_ID;
                        cmd.Parameters.Add(inAVPR_KORR_ANFO_POS_ID);

                        OracleParameter inTYP = new OracleParameter("inTYP", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                        inTYP.Value = TYP;
                        cmd.Parameters.Add(inTYP);

                        OracleParameter inMODELL = new OracleParameter("inMODELL", OracleDbType.Varchar2, System.Data.ParameterDirection.Input);
                        inMODELL.Value = eingabeRohdaten[i].Modell;              
                        cmd.Parameters.Add(inMODELL);

                        OracleParameter inAVPR_KORR_ANFO_ROHDATEN_ID = new OracleParameter("inAVPR_KORR_ANFO_ROHDATEN_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                        inAVPR_KORR_ANFO_ROHDATEN_ID.Value = eingabeRohdaten[i].AVPR_KORR_ANFO_ROHDATEN_ID;
                        cmd.Parameters.Add(inAVPR_KORR_ANFO_ROHDATEN_ID);

                        OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                        cmd.Parameters.Add(result);

                        cmd.ExecuteNonQuery();
                        if (result.Value.ToString() == "1")
                        {

                        }
                        else
                        {
                            gesamtResult = gesamtResult + "ERROR: " + result.Value;
                        }
                    }

                }
                con.Dispose();
                con.Close();
                return gesamtResult;

            }
        }

        public string RECALC_AVPR_KORR_ANFO_POS(Int32 AVPR_KORR_ANFO_POS_ID)
        {
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    string jsonString = "";
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.RECALC_AVPR_KORR_ANFO_POS";

                    OracleParameter inAVPR_KORR_ANFO_POS_ID = new OracleParameter("inAVPR_KORR_ANFO_POS_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_POS_ID.Value = AVPR_KORR_ANFO_POS_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_POS_ID);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    jsonString=result.Value.ToString();
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string RECALC_AVPR_KORR_ANFO_POSIDS(Int32[] AVPR_KORR_ANFO_POS_IDs)
        {
                    string jsonString = "";

                    for (int i = 0; i < AVPR_KORR_ANFO_POS_IDs.Length; i++)
                    {
                        jsonString += RECALC_AVPR_KORR_ANFO_POS(AVPR_KORR_ANFO_POS_IDs[i]);
                    }              
                    return jsonString;
                
            
        }

        public string GET_AVPR_KORR_ANFO_EVART_LST(Int32 AVPR_KORR_ANFO_ID)
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_EVART_LST";

                    OracleParameter inAVPR_KORR_ANFO_ID = new OracleParameter("inAVPR_KORR_ANFO_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_ID.Value = AVPR_KORR_ANFO_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_ID);

                    OracleParameter outAVPRKORRANFOEVARTLST = new OracleParameter("outAVPRKORRANFOEVARTLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOEVARTLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);


                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

        public string GET_AVPR_KORR_ANFO_PROT_LST(Int32 AVPR_KORR_ANFO_ID)
        {
            string jsonString = "";
            using (OracleConnection con = new OracleConnection(_connectionStringProd))
            {
                using (OracleCommand cmd = new OracleCommand("", con))
                {
                    con.Open();
                    cmd.BindByName = true;
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "SF_ADDON.PKG_RI_AVPR_KORR.GET_AVPR_KORR_ANFO_PROT_LST";

                    OracleParameter inAVPR_KORR_ANFO_ID = new OracleParameter("inAVPR_KORR_ANFO_ID", OracleDbType.Int32, System.Data.ParameterDirection.Input);
                    inAVPR_KORR_ANFO_ID.Value = AVPR_KORR_ANFO_ID;
                    cmd.Parameters.Add(inAVPR_KORR_ANFO_ID);

                    OracleParameter outAVPRKORRANFOPROTLST = new OracleParameter("outAVPRKORRANFOPROTLST", OracleDbType.RefCursor, System.Data.ParameterDirection.Output);
                    cmd.Parameters.Add(outAVPRKORRANFOPROTLST);

                    OracleParameter result = new OracleParameter("result", OracleDbType.Int32, System.Data.ParameterDirection.ReturnValue);
                    cmd.Parameters.Add(result);

                    cmd.ExecuteNonQuery();

                    var reader = cmd.ExecuteReader(CommandBehavior.KeyInfo);
                    ReaderToJsonClass rj = new ReaderToJsonClass();
                    jsonString += rj.getJsonFromReader(reader);
                    con.Dispose();
                    con.Close();
                    return jsonString;
                }
            }
        }

    }
}