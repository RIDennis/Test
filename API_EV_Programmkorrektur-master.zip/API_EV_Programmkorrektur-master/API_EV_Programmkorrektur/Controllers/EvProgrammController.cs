using API_EV_Programmkorrektur.Interfaces;
using API_EV_Programmkorrektur.Models;
using Microsoft.AspNetCore.Mvc;

namespace API_EV_Programmkorrektur.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class EvProgrammController : ControllerBase
    {
        IEvProgrammService EvProgrammService;

        public EvProgrammController(IEvProgrammService _EvProgrammService)
        {
            EvProgrammService = _EvProgrammService;
        }

        [HttpGet("GetSaisonList")]
        public string GetSaisonList()
        {
            var result = EvProgrammService.GetSaisonList();
            return result;
        }

        [HttpGet("GetUebersicht")]
        public string GetUebersicht()
        {
            var result = EvProgrammService.GetUebersicht();
            return result;
        }

        [HttpGet("GetVOList")]
        public string GetVOList()
        {
            var result = EvProgrammService.GetVOList();
            return result;
        }

        [HttpPost("CreateProcess")]
        public string CreateProcess([FromBody] process s)
        {
            var result = EvProgrammService.createProcess(s);
            return result;
        }

        [HttpGet("GET_AVPR_KORR_ANFO_POS_LST/{id}")]
        public string GET_AVPR_KORR_ANFO_POS_LST(Int32 id)
        {
            string result = EvProgrammService.GET_AVPR_KORR_ANFO_POS_LST(id);
            return result;
        }

        [HttpGet("GET_AVPR_KORR_ANFO_EVART_LST/{id}")]
        public string GET_AVPR_KORR_ANFO_EVART_LST(Int32 id)
        {
            string result = EvProgrammService.GET_AVPR_KORR_ANFO_EVART_LST(id);
            return result;
        }

        [HttpGet("GET_AVPR_KORR_ANFO_PROT_LST/{id}")]
        public string GET_AVPR_KORR_ANFO_PROT_LST(Int32 id)
        {
            string result = EvProgrammService.GET_AVPR_KORR_ANFO_PROT_LST(id);
            return result;
        }

        [HttpGet("GET_AVPR_KORR_ANFO_POS_LST/{id}/{TYP}")]
        public string GET_AVPR_KORR_ANFO_POS_LST(Int32 id, String TYP)
        {
            string result = EvProgrammService.GET_AVPR_KORR_ANFO_POS_LST(id, TYP);
            return result;
        }


        [HttpGet("GET_AVPR_KORR_ANFO_ROH_LST/{id}/{Posid}/{Typ}")]
        public string GET_AVPR_KORR_ANFO_ROH_LST(Int32 id, Int32 Posid, String Typ)
        {
            string result = EvProgrammService.GET_AVPR_KORR_ANFO_ROH_LST(id, Posid, Typ);
            return result;
        }

        [HttpPost("MOD_AVPR_KORR_ANFO_ROHDATEN/{Typ}")]
        public string MOD_AVPR_KORR_ANFO_ROHDATEN(String Typ, [FromBody] ModDataObject[] s)
        {
            var result = EvProgrammService.MOD_AVPR_KORR_ANFO_ROHDATEN(Typ, s);
            return result;
        }

        [HttpGet("RECALC_AVPR_KORR_ANFO_POS/{Posid}")]
        public string RECALC_AVPR_KORR_ANFO_POS(Int32 Posid)
        {
            string result = EvProgrammService.RECALC_AVPR_KORR_ANFO_POS(Posid);
            return result;
        }

        [HttpPost("RECALC_AVPR_KORR_ANFO_POSIDS")]
        public string RECALC_AVPR_KORR_ANFO_POSIDS([FromBody] Int32[] s)
        {
            string result = EvProgrammService.RECALC_AVPR_KORR_ANFO_POSIDS(s);
            return result;
        }

    }
}